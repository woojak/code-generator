#!/usr/bin/env python3
from pathlib import Path
import re, sys, subprocess

p = Path("app/src/main/java/com/labeltools/palletlabel/OcrParser.java")
if not p.exists():
    print("ERROR: uruchom w katalogu głównym repo code-generator.")
    sys.exit(1)

text = p.read_text(encoding="utf-8")

articles = r'''    private static void parseArticles(List<String> lines, OcrResult r) {
        Pattern inline = Pattern.compile(
                "(?i)art\\s*\\.?\\s*nr\\s*\\.?\\s*(tu\\s*/\\s*cu|cu\\s*/\\s*tu|tu|cu)\\s*[:.-]?\\s*(\\d{5,12})");
        Pattern reversed = Pattern.compile(
                "(?i)\\b(tu\\s*/\\s*cu|cu\\s*/\\s*tu|tu|cu)\\s+art\\s*\\.?\\s*nr\\s*\\.?\\s*[:.-]?\\s*(\\d{5,12})");
        Pattern labelOnly = Pattern.compile(
                "(?i)^.*art\\s*\\.?\\s*nr\\s*\\.?\\s*(tu\\s*/\\s*cu|cu\\s*/\\s*tu|tu|cu)\\s*[:.-]?\\s*$");
        Pattern valueOnly = Pattern.compile("^\\d{5,12}$");

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            String kind = "";
            String value = "";

            Matcher m = inline.matcher(line);
            if (m.find()) {
                kind = m.group(1);
                value = m.group(2);
            } else {
                m = reversed.matcher(line);
                if (m.find()) {
                    kind = m.group(1);
                    value = m.group(2);
                } else {
                    m = labelOnly.matcher(line);
                    if (m.matches() && i + 1 < lines.size()) {
                        Matcher next = valueOnly.matcher(lines.get(i + 1).trim());
                        if (next.matches()) {
                            kind = m.group(1);
                            value = next.group();
                        }
                    }
                }
            }

            if (!value.isEmpty()) {
                applyArticleValue(r, kind, value);
                r.mark("article", OcrResult.Confidence.HIGH);
            }
        }

        if (!r.articleCu.isEmpty()) r.article = r.articleCu;
        else if (!r.articleTu.isEmpty()) r.article = r.articleTu;
    }

    private static void applyArticleValue(OcrResult r, String kindRaw, String value) {
        String kind = kindRaw.toUpperCase(Locale.ROOT).replaceAll("\\s+", "");
        if (kind.contains("/")) {
            r.articleTu = value;
            r.articleCu = value;
        } else if (kind.equals("TU")) {
            r.articleTu = value;
        } else if (kind.equals("CU")) {
            r.articleCu = value;
        }
    }

'''

batch = r'''    private static void parseBatch(List<String> lines, OcrResult r) {
        Pattern inline = Pattern.compile(
                "(?i)^.*?\\bbatch\\s*(?:code|/\\s*lot)?\\s*[:.-]?\\s*([A-Z0-9][A-Z0-9-]{2,19})\\s*$");
        Pattern lot = Pattern.compile(
                "(?i)^.*?\\blot\\s*[:.-]?\\s*([A-Z0-9][A-Z0-9-]{2,19})\\s*$");
        Pattern labelOnly = Pattern.compile(
                "(?i)^.*?\\b(?:batch(?:\\s*code|\\s*/\\s*lot)?|lot)\\s*[:.-]?\\s*$");
        Pattern token = Pattern.compile("(?i)^[A-Z0-9][A-Z0-9-]{2,19}$");

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            Matcher m = inline.matcher(line);
            if (!m.matches()) m = lot.matcher(line);

            if (m.matches()) {
                String value = m.group(1).trim();
                if (isUsableBatch(value)) {
                    r.batch = value;
                    r.mark("batch", OcrResult.Confidence.HIGH);
                    return;
                }
            }

            if (labelOnly.matcher(line).matches() && i + 1 < lines.size()) {
                String value = lines.get(i + 1).trim();
                if (token.matcher(value).matches() && isUsableBatch(value)) {
                    r.batch = value;
                    r.mark("batch", OcrResult.Confidence.HIGH);
                    return;
                }
            }
        }

        if (r.detectedType.equals("SEMIFINISHED")) {
            Pattern semiBatch = Pattern.compile("(?i)^(?:[A-Z]{1,6}\\d{2,8}|\\d{2,8}[A-Z]{1,6})$");
            for (String line : lines) {
                String value = line.trim();
                if (semiBatch.matcher(value).matches() && isUsableBatch(value)) {
                    r.batch = value;
                    r.mark("batch", OcrResult.Confidence.MEDIUM);
                    return;
                }
            }
        }
    }

    private static boolean isUsableBatch(String value) {
        if (value == null) return false;
        String v = value.trim();
        if (v.length() < 3 || v.length() > 20) return false;
        String u = v.toUpperCase(Locale.ROOT);
        return !u.equals("RITUALS")
                && !u.equals("CODE")
                && !u.equals("BATCH")
                && !u.equals("LOT")
                && !u.equals("SEMIFINISHED");
    }

'''

text2, n1 = re.subn(
    r'    private static void parseArticles\(List<String> lines, OcrResult r\) \{.*?\n    \}\n\n    private static void applyArticleValue\(OcrResult r, String kindRaw, String value\) \{.*?\n    \}\n\n',
    lambda m: articles,
    text,
    count=1,
    flags=re.S
)
if n1 != 1:
    print("ERROR: nie znaleziono sekcji parseArticles/applyArticleValue.")
    sys.exit(2)

text3, n2 = re.subn(
    r'    private static void parseBatch\(List<String> lines, OcrResult r\) \{.*?\n    \}\n\n    private static boolean isUsableBatch\(String value\) \{.*?\n    \}\n\n',
    lambda m: batch,
    text2,
    count=1,
    flags=re.S
)
if n2 != 1:
    print("ERROR: nie znaleziono sekcji parseBatch/isUsableBatch.")
    sys.exit(3)

p.write_text(text3, encoding="utf-8")

print("Regex escape fix zastosowany.")
subprocess.run(["git", "diff", "--check"], check=False)
print()
print('Teraz:')
print('git add app/src/main/java/com/labeltools/palletlabel/OcrParser.java')
print('git commit -m "Fix v1.2.1 Java regex escaping"')
print('git push')
